import json
import os
from io import StringIO
import pandas as pd
import csv
import boto3


def df_to_s3(dataframe, filename, bucket):
    """ Write a dataframe to a tsv on S3 """
    # buffer
    csv_buffer = StringIO()
    dataframe.to_csv(csv_buffer, sep="\t", index=False)
    # create S3 object and write to it
    s3_resource = boto3.resource("s3")
    s3_resource.Object(bucket, f'{filename}').put(
        Body=csv_buffer.getvalue())


def parse_transcript(json_object):
    whole_data = json.loads(json_object)
    items = whole_data['results']['items']

    # init sentences, start and end time
    sentences = []
    sentence_string = ''
    start_time = float(items[0]['start_time'])
    end_time = float(items[0]['end_time'])
    sentence = {}
    restart_time = False

    # loop through words
    for item in items:
        if item['type'] == 'punctuation' and item['alternatives'][0]['content'] in ['.', '?', "!"]:
            sentence_string += item['alternatives'][0]['content']
            sentence['start_time'] = start_time
            sentence['end_time'] = end_time
            sentence['content'] = sentence_string
            sentences.append(sentence)

            sentence_string = ''
            sentence = {}
            restart_time = True

        else:
            sentence_string += ' ' + item['alternatives'][0]['content']
            if item['type'] == 'pronunciation':
                if restart_time:
                    start_time = float(item['start_time'])
                    restart_time = False
                end_time = float(item['end_time'])

    return sentences  # a list of dict objects


def lambda_handler(event, context):
    # variables from event
    BUCKET = event['Records'][0]['s3']['bucket']['name']
    KEY = event['Records'][0]['s3']['object']['key']

    filename = KEY.split('.')[0]
    outputname = 'segment_' + filename + '.tsv'

    # get file from S3
    s3_client = boto3.client('s3')
    response = s3_client.get_object(Bucket=BUCKET, Key=KEY)
    json_file = response["Body"].read()  # a streamingBody object
    parsed_sentences = parse_transcript(json_file)
    # to dataframe and then tsv
    df = pd.DataFrame(parsed_sentences)
    df_to_s3(df, outputname, BUCKET)

    # standard return message
    return {
        'statusCode': 200,
        'message': 'Success!'}

