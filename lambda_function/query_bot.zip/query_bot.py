import pandas as pd
import boto3
import os
from io import StringIO


def df_to_s3(dataframe, filename, bucket):
    # buffer
    csv_buffer = StringIO()
    dataframe.to_csv(csv_buffer, sep="\t", index=False)
    # create S3 object and write to it
    s3_resource = boto3.resource("s3")
    s3_resource.Object(bucket, f'{filename}').put(
        Body=csv_buffer.getvalue())


def code_sentences(csv_file, client, bot):
    df = pd.read_csv(csv_file, sep="\t")
    for i in df.index:
        sentence = df.at[i, 'content']
        response = client.post_text(
            botName=bot['name'],
            botAlias=bot['alias'],
            userId='admin',
            inputText=sentence
        )
        df.at[i, 'BotCode'] = response['message']

    return df


def lambda_handler(event, context):
    # clients to be used
    s3_client = boto3.client('s3')
    lex_client = boto3.client('lex-runtime')

    try:
        # info from invoke
        BUCKET = event.get('bucket')
        KEY = event.get('file_key')
        OUTPUT = event.get('output_file')
        BOT = event.get('bot')

        # get file from s3
        response = s3_client.get_object(Bucket=BUCKET, Key=KEY)
        sentences = response['Body']
        coded = code_sentences(sentences, lex_client, BOT)  # df
        df_to_s3(coded, OUTPUT, BUCKET)

        # standard return message
        return {
            'statusCode': 200,
            'message': 'File coded.'}

    except:
        return {
            'statusCode': 400,
            'body': 'Error, bad request!'}